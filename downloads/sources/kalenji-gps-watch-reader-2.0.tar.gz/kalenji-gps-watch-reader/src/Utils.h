#ifndef _UTILS_H
#define _UTILS_H

#include <string>

std::string durationAsString(double sec, bool with_hundredth = false);

#endif
