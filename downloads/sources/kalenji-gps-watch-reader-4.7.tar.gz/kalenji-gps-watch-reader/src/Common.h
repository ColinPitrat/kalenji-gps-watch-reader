#ifndef _COMMON_H_
#define _COMMON_H_

#define KALENJI_EXPORT_MAX_POINTS 250

#endif
